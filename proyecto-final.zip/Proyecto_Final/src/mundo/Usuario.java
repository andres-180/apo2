package mundo;

public class Usuario {

	public final static int VIDAS = 3;
	
	private String nombre;
	private int puntaje;
	private String id;
	private int vidas;
	private int edad;
	private String imagen;
	private Usuario siguiente;
	private Usuario anterior;
	
	public Usuario(String nombre, int edad,String id, String imagen) {
		this.nombre = nombre;
		this.puntaje = 0;
		this.id = id;
		this.vidas = 3;
		this.siguiente = null;
		this.anterior = null;
		this.edad = edad;
		this.imagen = imagen;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public String getNombre() {
		return nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getVidas() {
		return vidas;
	}

	public void setVidas(int vidas) {
		this.vidas = vidas;
	}

	public Usuario getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(Usuario siguiente) {
		this.siguiente = siguiente;
	}

	public Usuario getAnterior() {
		return anterior;
	}

	public void setAnterior(Usuario anterior) {
		this.anterior = anterior;
	}
	
	public int cantidadVidaRestantes() {
		return vidas;
	}
	
	public int cantidadPuntosAcumulados() {

		return 0;

	}
	
	public String toString(){
		return  nombre=nombre;
	}

}
