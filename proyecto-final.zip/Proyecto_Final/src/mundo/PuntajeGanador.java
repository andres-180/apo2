package mundo;

import java.util.Collection;

public class PuntajeGanador {
	private int puntaje;
	private PuntajeGanador izq;
	private PuntajeGanador der;

	public PuntajeGanador(int puntaje) {
		this.puntaje = puntaje;
		izq = null;
		der = null;
	}

	
	public boolean esHoja() {
		return izq == null && der == null;
	}

	public PuntajeGanador darMenor() {
		return (izq == null) ? this : izq.darMenor();
	}


	public PuntajeGanador darMayor() {
		return (der == null) ? this : der.darMayor();
	}

	
	public int darAltura() {
		if (esHoja())
			return 1;
		else {
			int a1 = (izq == null) ? 0 : izq.darAltura();
			int a2 = (der == null) ? 0 : der.darAltura();
			return 1 + Math.max(a1, a2);
		}
	}
	 /**
     * Retorna el n�mero de puntajes que hay en el �rbol que comienza en este nodo
     * @return n�mero de puntajes en el �rbol que comienza en este nodo
     */
    public int darPeso( )
    {
        int p1 = ( izq == null ) ? 0 : izq.darPeso( );
        int p2 = ( der == null ) ? 0 : der.darPeso( );
        return 1 + p1 + p2;
    }
	
	 public int contarHojas( )
	    {
	        if( esHoja( ) )
	            return 1;
	        else
	        {
	            int h1 = ( izq == null ) ? 0 : izq.contarHojas( );
	            int h2 = ( der == null ) ? 0 : der.contarHojas( );
	            return h1 + h2;
	        }
	    }

	   
	    public void insertar( PuntajeGanador nuevo ) throws  NoExisteException
	    {
	        if( puntaje == nuevo.getPuntaje() )
	            throw new NoExisteException( "Ya existe" );

	        if(  puntaje > nuevo.getPuntaje() )
	        {
	           
	            if( izq == null )
	                izq = nuevo;
	            else
	                izq.insertar( nuevo );
	        }
	        else
	        {
	        
	            if( der == null )
	                der = nuevo;
	            else
	                der.insertar( nuevo );
	        }
	    }
	    
	    
	    public PuntajeGanador eliminar( int punta )
	    {
	        if( esHoja( ) )
	            // Tiene que ser el elemento que estamos buscando
	            return null;
	        if( puntaje == punta )
	        {
	            if( izq == null )
	                return der;
	            if( der == null )
	                return izq;
	            // Localiza el menor puntaje del sub�rbol derecho
	            PuntajeGanador sucesor = der.darMenor( );
	            // Elimina del sub�rbol derecho el elemento que acaba de localizar
	            der = der.eliminar( sucesor.getPuntaje( ) );
	            // Deja el elemento localizado en la ra�z del �rbol de respuesta
	            sucesor.izq = izq;
	            sucesor.der = der;
	            return sucesor;
	        }
	        else if( puntaje>punta )
	            izq = izq.eliminar( punta );
	        else
	            der = der.eliminar( punta );
	        return this;
	    }
	    

	    public void inorden( Collection acumulado )
	    {
	       
	        if( izq != null )
	            izq.inorden( acumulado );
	      
	        acumulado.add( puntaje );
	    
	        if( der != null )
	            der.inorden( acumulado );
	    }
	    
	    /**
	     * Retorna una colecci�n con los puntajes de todos los usuarios,desordenados
	     * @param acumulado colecci�n donde se van agregando los puntajes de los usuarios
	     */
	    public void preorden( Collection acumulado )
	    {
	    	
	        acumulado.add(puntaje );
	        
	        if( izq != null )
	            izq.preorden( acumulado );
	      
	        if( der != null )
	            der.preorden( acumulado );
	    }
	    
	    /**
	     * Retorna una colecci�n con los puntajes de los usuarios, desordenados
	     * @param acumulado colecci�n donde se van agregando los puntajes de los usuarios 
	     */
	    public void postOrden( Collection acumulado )
	    {
	       
	        if( izq != null )
	            izq.postOrden( acumulado );
	       
	        if( der != null )
	            der.postOrden( acumulado );
	     
	        acumulado.add( puntaje );
	    }


	    /**
	     * Indica si el �rbol que comienza en este nodo es ordenado
	     * @return true si el �rbol que comienza en este nodo es ordenado
	     */
	    public boolean esOrdenado( )
	    {
	        if( esHoja( ) )
	            return true;

	        else if( izq == null )
	            return der.esOrdenado( ) && puntaje <  der.darMenor( ).getPuntaje() ;

	        else if( der == null )
	            return izq.esOrdenado( ) && puntaje >  izq.darMenor( ).getPuntaje();

	        else
	            return der.esOrdenado( ) && puntaje <  der.darMenor( ).getPuntaje() && izq.esOrdenado( ) &&  puntaje >  izq.darMenor( ).getPuntaje();
	    }

	    public int getPuntaje() {
			return puntaje;
		}

		public void setPuntaje(int puntaje) {
			this.puntaje = puntaje;
		}

		public PuntajeGanador getIzq() {
			return izq;
		}

		public void setIzq(PuntajeGanador izq) {
			this.izq = izq;
		}

		public PuntajeGanador getDer() {
			return der;
		}

		public void setDer(PuntajeGanador der) {
			this.der = der;
		}

	   
	  


}
