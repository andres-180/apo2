package mundo;

import java.util.ArrayList;

public class Nivel {
	private ArrayList<Zombie> zombies;
	public final static String RUTA_ZOMBIE = "img/bloggif_56427e72aaee2.gif";
	private int cont = 0;

	public Nivel(int nivel) {
		zombies = new ArrayList<Zombie>();

	}

	public ArrayList<Zombie> getZombies() {
		return zombies;

	}

	public void setZombies() {
		zombies = new ArrayList<Zombie>();
	}
	
	
	public Zombie agregarZombie(int ancho, int alto, int cantidadBrazos, int cantidadPiernas, int CantidadPuntos,
			int asesino, int posx1, int posy1, String ruta1, int direccion, int velocidad, int aleatorio, int nivel) {
		if (aleatorio <= 4) {
			Zombie a = new BebeZombie(ancho, alto, cantidadBrazos, cantidadPiernas, CantidadPuntos, asesino, posx1 + 50,
					posy1 + 100, ruta1, direccion, velocidad, nivel);
			zombies.add(a);
			return a;
		} else if (aleatorio > 4 && aleatorio <= 9) {
			Zombie a = new ZombiePrincipiante(ancho, alto, cantidadBrazos, cantidadPiernas, CantidadPuntos, 10, 5, posx1 + 10,
					posy1 + 50, ruta1, direccion, velocidad, nivel);
			zombies.add(a);
			return a;

		} else if (aleatorio > 9 && aleatorio <= 14) {
			Zombie a = new AsesinoZombie(ancho, alto, cantidadBrazos, cantidadPiernas, CantidadPuntos, 20, 30, 10,
					posx1 + 100, posy1 + 50, ruta1, direccion, velocidad, nivel);
			zombies.add(a);
			return a;

		} else if (aleatorio > 14 && aleatorio <= 19) {
			Zombie a = new PapaZombie(ancho, alto, cantidadBrazos, cantidadPiernas, CantidadPuntos, 30, 20, posx1 + 10,
					posy1 + 30, ruta1, direccion, velocidad, nivel);
			zombies.add(a);
			return a;

		}

		return null;

	}

}
