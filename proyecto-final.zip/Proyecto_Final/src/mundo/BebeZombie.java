package mundo;

public class BebeZombie extends Zombie{

	private int asesino;
	public final static int ASESINO = 0;
	public final static int Puntos=20;
	public final static int ARR = 0;
	public final static int ABA = 1;
	public final static int IZQ = 2;
	public final static int DER = 3;
	
	public final static int nivel0 = 0;
	public final static int nivel1 = 1;
	public final static int nivel2 = 2;
	public final static int nivel3 = 3;
	private int dormir;
	
	
	
	public BebeZombie(int ancho,int alto,int cantidadBrazos, int cantidadPiernas, int CantidadPuntos, int asesino,int posx1,int posy1,String ruta1
			,int direccion, int velocidad,int nivel1) {
		super(ancho,alto,cantidadBrazos, cantidadPiernas, CantidadPuntos,posx1,posy1,ruta1,direccion,velocidad,nivel1);
		posx=posx1;
		posy=posy1;
		this.asesino = asesino;
		this.ancho=ancho;
		this.alto=alto;
		ruta=ruta1;
		nivel=nivel1;
	}

	@Override
	public int getCantidadBrazos() {
		return super.getCantidadBrazos();
	}

	@Override
	public int getCantidadPiernas() {
		return super.getCantidadPiernas();
	}

	@Override
	public int getCantidadPuntos() {
		return super.getCantidadPuntos();
	}

	public String getRuta() {
		return ruta;
	}
	


	public int getposx() {
	
		return posx;
	}
	
	public int getalto()
	{
		return alto;
	}
	
	public int getancho()
	{
		return ancho;
	}
	
	
	
	
	
	

	public int getposy() {

		return posy;
	}
	
	public int getAsesino() {
		return asesino;
	}
	
	public int getpuntos() {
	return Puntos;
	}
	
 
     
     public void mover()
     {
    	 direccion = (int)(Math.random()*4);
    	 if(posx<100){
 			direccion = DER;
 		}
 		if(posy<100){
 			direccion = ABA;
 		}
 		if(posx>1000){
 			direccion = IZQ;
 		}
 		if(posy>550){
 			direccion = ARR;
 		}
    
 		switch(direccion){
 		
 			case ARR: posy = posy - velocidad; break;
 			case ABA: posy = posy + velocidad; break;
 			case IZQ: posx = posx - velocidad; break;
 			case DER: posx = posx + velocidad; break;
 		}
 		
 		
    	 
     }
     
     
  
	
	void verificarInvariantes() {
		assert cantidadBrazos != 0 : "al menos debe tener un brazo";
		assert cantidadPiernas != 0 : "debe tener al menos una pierna";
		assert cantidadPuntos != 0 : "debe tener propios numeros";

	}

	public long dormir() {
		switch(nivel){
 		
			case nivel0: dormir=((int)(Math.random()*(1500-1100))+1100); break;
			case nivel1: dormir = ((int)(Math.random()*(900-1000))+1000); break;
			case nivel2: dormir= ((int)(Math.random()*(800-600))+600); break;
			case nivel3: dormir = ((int)(Math.random()*(500-300))+300); break;
		}
		return dormir;
	}

	
}
