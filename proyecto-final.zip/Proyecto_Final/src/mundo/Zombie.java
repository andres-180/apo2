package mundo;

public class Zombie {
	protected int cantidadBrazos;
	protected  int cantidadPiernas;
	protected  int cantidadPuntos;
	protected int posx;
	protected int posy;
	protected String ruta;
	protected int ancho;
	protected int alto;
	protected int direccion;
	protected int velocidad;
	protected int nivel;


	public Zombie(int ancho, int alto, int cantidadBrazos, int cantidadPiernas, int CantidadPuntos,int posx1, int posy1,String ruta1
			,int direccion1,int velocidad1,int nivel1) {
		this.cantidadBrazos = cantidadBrazos;
		posx=posx1;
		posy=posy1;
		this.cantidadPiernas = cantidadPiernas;
		this.cantidadPuntos = CantidadPuntos;
         ruta=ruta1;
         this.ancho=ancho;
         this.alto=alto;
         this.direccion=direccion1;
         this.velocidad=velocidad1;
         nivel=nivel1;
	}

	public int getCantidadBrazos() {
		return cantidadBrazos;
	}

     public String getRuta() {
		return ruta;
	}
     
	
	public int getCantidadPiernas() {
		return cantidadPiernas;
	}

	public int getCantidadPuntos() {
		return cantidadPuntos;
	}

	void verificarInvariantes() {
		assert cantidadBrazos != 0 : "al menos debe tener un brazo";
		assert cantidadPiernas != 0 : "debe tener al menos una pierna";
		assert cantidadPuntos != 0 : "debe tener propios numeros";

	}

	public void setPosX(int i) {
		posx=i;
		
	}

	
}
