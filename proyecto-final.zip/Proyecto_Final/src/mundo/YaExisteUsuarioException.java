package mundo;

public class YaExisteUsuarioException extends Exception {

	String mensaje;
	
	public YaExisteUsuarioException(String msg){
		mensaje=msg;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
