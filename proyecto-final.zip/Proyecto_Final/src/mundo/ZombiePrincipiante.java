package mundo;

public class ZombiePrincipiante extends Zombie{
	private int resistencia;
	private int frecuencia;
	public final static String CUCHILLO = "cuchillo";
	private int cantidadBrazos;
	public final static int PUNTOS_PRINCIPIANTE = 30;
	public final static int CANTIDAD_BRAZOS = 1;
	public final static int RESISTENCIA = 10;
	public final static int FRECUENCIA = 5;
	
	public final static int ARR = 0;
	public final static int ABA = 1;
	public final static int IZQ = 2;
	public final static int DER = 3;
	
	public final static int nivel0 = 0;
	public final static int nivel1 = 1;
	public final static int nivel2 = 2;
	public final static int nivel3 = 3;
	private int nivel;
	private int dormir;
	
	
	
	public ZombiePrincipiante(int ancho,int alto,int cantidadBrazos, int cantidadPiernas, int CantidadPuntos, int resistencia, int frecuencia,int posx1,int posy1,String ruta1
			,int direccion, int velocidad, int nivel1) {
		super(ancho,alto,cantidadBrazos, cantidadPiernas, CantidadPuntos, posx1, posy1,ruta1,direccion,velocidad,nivel1);
		this.resistencia = resistencia;
		this.frecuencia = frecuencia;
		posx1=posx;
		posy1=posy;
		this.ancho=ancho;
		this.alto=alto;
		ruta=ruta1;

	}

	public int getResistencia() {
		return resistencia;
	}

	public int getFrecuencia() {
		return frecuencia;
	}
    public void mover()
    {
   	 direccion = (int)(Math.random()*4);
   	if(posx<100){
		direccion = DER;
	}
	if(posy<100){
		direccion = ABA;
	}
	if(posx>1000){
		direccion = IZQ;
	}
	if(posy>550){
		direccion = ARR;
	}


		switch(direccion){
			case ARR: posy = posy - velocidad; break;
			case ABA: posy = posy + velocidad; break;
			case IZQ: posx = posx - velocidad; break;
			case DER: posx = posx + velocidad; break;
		}
		
		
		
   	 
    }
    
    
	@Override
	public int getCantidadPuntos() {
		return PUNTOS_PRINCIPIANTE;
	}

	public  String getRuta() {
		return ruta;
	}
	public int getAncho() {
		return ancho;
	}
	public  int getAlto() {
		return alto;
	}
	
	
	@Override
	public int getCantidadBrazos() {
		return CANTIDAD_BRAZOS;
	}

	void verificarInvariantes() {
		assert cantidadBrazos != 0 : "al menos debe tener un brazo";
		assert cantidadPiernas != 0 : "debe tener al menos una pierna";
		assert cantidadPuntos != 0 : "debe tener propios numeros";

	}

	public int getposx() {
		// TODO Auto-generated method stub
		return posx;
	}

	public int getposy() {
		// TODO Auto-generated method stub
		return posy;
	}

	public long dormir() {
		switch(nivel){
 		
		case nivel0: dormir=((int)(Math.random()*(1500-1100))+1100); break;
		case nivel1: dormir = ((int)(Math.random()*(900-1000))+1000); break;
		case nivel2: dormir= ((int)(Math.random()*(800-600))+600); break;
		case nivel3: dormir = ((int)(Math.random()*(500-300))+300); break;
	}
	return dormir;
	}

}
