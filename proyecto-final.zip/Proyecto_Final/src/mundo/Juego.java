package mundo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Juego {

	private int cantidadusuarios;
	private Usuario primerUsuario;
	private Nivel niveles;
	private int niveldentra;
	private int anchox;
	private int anchoy;
	private PuntajeGanador ganadorRaiz;

	public Juego(int nivels, int anchox, int anchoy) {

		niveles = new Nivel(nivels);
		niveldentra = nivels;
		this.anchox = anchox;
		this.anchoy = anchoy;

		File archivo = new File("./docs/usuarios()");
		if (archivo.exists()) {
			try {

				System.out.println("entra");
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo));
				primerUsuario = (Usuario) ois.readObject();
				ois.close();

			} catch (Exception e) {
				System.out.println("error");

			}
		} else {
			primerUsuario = null;
		}

	}

	public int getAnchox() {
		return anchox;
	}

	public int getAnchoy() {
		return anchoy;
	}

	public boolean agregarUsuario(String nombre, int edad, String id, String imagen) throws  YaExisteUsuarioException {
		boolean agrego = false;
		Usuario usuario = new Usuario(nombre, edad, id, imagen);

		if (primerUsuario == null) {
			primerUsuario = usuario;
			agrego = true;
		} else {
			return agregarRecursivo(usuario, primerUsuario);
		}
		return agrego;
	}

	private boolean agregarRecursivo(Usuario usuario, Usuario actual) throws YaExisteUsuarioException {
		boolean agrego = true;
		if (!actual.getId().equals(usuario.getId())) {
			if (actual.getSiguiente() == null) {
				usuario.setAnterior(actual);
				actual.setSiguiente(usuario);
				agrego = true;
			} else
				agregarRecursivo(usuario, actual.getSiguiente());

		} else
			throw new YaExisteUsuarioException("Ya existe el Usuario");

		return agrego;
	}

	public void agregarPuntajesAlArbol() throws NoExisteException {
		for (int i = 0; i < usuarios().size(); i++) {
			Usuario uno = usuarios().get(i);

			PuntajeGanador nuevo = new PuntajeGanador(uno.getPuntaje());
			if (ganadorRaiz == null)
				ganadorRaiz = nuevo;
			else
				ganadorRaiz.insertar(nuevo);
		}

	}

	/**
	 * Retorna una lista ordenada con los puntajes de los usuarios
	 * 
	 * @return lista de puntajes ordenada por orden alfab�tico. Si la lista est�
	 *         vac�a retorna null
	 */
	public Collection darListaPuntajesInorden() {
		if (ganadorRaiz == null)
			return null;
		else {
			Collection resp = new ArrayList();
			ganadorRaiz.inorden(resp);
			return resp;
		}
	}

	public Usuario getPrimerUsuario() {
		return primerUsuario;
	}

	public void setPrimerUsuario(Usuario primerUsuario) {
		this.primerUsuario = primerUsuario;
	}

	public PuntajeGanador getGanadorRaiz() {
		return ganadorRaiz;
	}

	public void setGanadorRaiz(PuntajeGanador ganadorRaiz) {
		this.ganadorRaiz = ganadorRaiz;
	}

	/**
	 * Retorna una lista desordenada con los puntajes de los usuarios
	 * 
	 * @return lista de usuarios en desorden. Si la lista est� vac�a retorna
	 *         null
	 */
	public Collection darListaContactosPreorden() {
		if (ganadorRaiz == null)
			return null;
		else {
			Collection resp = new ArrayList();
			ganadorRaiz.preorden(resp);
			return resp;
		}
	}

	/**
	 * Retorna una lista desordenada con los puntajes de los usuarios
	 * 
	 * @return lista de usuarios en desorden. Si la lista est� vac�a retorna
	 *         null
	 */
	public Collection darListaContactosPostOrden() {
		if (ganadorRaiz == null)
			return null;
		else {
			Collection resp = new ArrayList();
			ganadorRaiz.postOrden(resp);
			return resp;
		}
	}

	/**
	 * Elimina del juego el puntaje buscado <br>
	 * <b>post: </b>El puntaje ha sido eliminado del juego <br>
	 * 
	 * @param puntaje
	 *            puntaje a eliminar
	 */
	public void eliminarPuntaje(int puntaje) {
		ganadorRaiz = ganadorRaiz.eliminar(puntaje);

	}

	/**
	 * Retorna la altura del �rbol de puntajes
	 * 
	 * @return La altura del �rbol de puntajes
	 */
	private int darAltura() {
		return ganadorRaiz == null ? 0 : ganadorRaiz.darAltura();
	}

	/**
	 * Retorna el menor puntajes del juego, teniendo en cuenta el orden puntajes
	 * 
	 * @return El puntaje menor del juego o null si el juego no tiene puntajes
	 */
	private PuntajeGanador darMenor() {
		return ganadorRaiz == null ? null : ganadorRaiz.darMenor();
	}

	/**
	 * Retorna el mayor puntaje del juego, teniendo en cuenta el orden los
	 * puntajes
	 * 
	 * @return El puntaje mayor del juego o null si el juego no tiene puntajes
	 */
	private PuntajeGanador darMayor() {
		return ganadorRaiz == null ? null : ganadorRaiz.darMayor();
	}

	/**
	 * Retorna el n�mero de hojas que tiene el �rbol de puntajes
	 * 
	 * @return N�mero de hojas que tiene el �rbol de puntajes
	 */
	private int contarHojas() {
		return ganadorRaiz == null ? 0 : ganadorRaiz.contarHojas();
	}

	/**
	 * Verifica que el �rbol binario est� ordenado
	 */
	private boolean esOrdenado() {
		return ganadorRaiz == null ? true : ganadorRaiz.esOrdenado();
	}

	/**
	 * Retorna el n�mero de puntajes que est�n en el juego
	 * 
	 * @return n�mero de puntajes presentes en el �rbol
	 */
	private int darPeso() {
		return ganadorRaiz == null ? 0 : ganadorRaiz.darPeso();
	}

	public ArrayList<Usuario> usuarios() {
		Usuario actual = primerUsuario;
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		while (actual != null) {
			usuarios.add(actual);
			actual = actual.getSiguiente();
		}
		return usuarios;
	}

	// burbuja
	public ArrayList<Usuario> ordenamientoBurbujaPorPuntaje() {
		ArrayList<Usuario> retorno = usuarios();
		for (int i = retorno.size() - 1; i > 0; i--) {
			for (int j = 0; j < i - 1; j++) {
				Usuario actual = (Usuario) retorno.get(j);
				Usuario allado = (Usuario) retorno.get(j + 1);

				if (actual.getPuntaje() > allado.getPuntaje()) {
					Usuario temporal = actual;
					retorno.set(j, retorno.get(j + 1));
				}

			}

		}

		return retorno;
	}

	// nombre insercion

	public ArrayList<Usuario> ordenamientoInsercionPorNombre() {
		ArrayList<Usuario> retorno = usuarios();
		for (int i = 1; i < retorno.size(); i++) {
			for (int j = i; j > 0 && retorno.get(j - 1).getNombre().compareTo(retorno.get(j).getNombre()) > 0; j--) {
				Usuario temp = retorno.get(j);
				retorno.set(j, retorno.get(j - 1));
				retorno.set(j - 1, temp);

			}

		}

		return retorno;
	}

	public int busquedaBinariaPorPuntaje(String id) {

		boolean encontrado = false;
		int inicio = 0;
		int fin = usuarios().size() - 1;
		int puntajeR = 0;
		while (inicio <= fin && !encontrado) {
			int medio = (inicio + fin) / 2;
			if (usuarios().get(medio).getId().compareTo(id) == 0) {
				puntajeR = usuarios().get(medio).getPuntaje();
				encontrado = true;
			} else if (usuarios().get(medio).getId().compareTo(id) > 0) {
				fin = medio - 1;
			} else {
				inicio = medio + 1;
			}

		}

		return puntajeR;

	}

	public boolean nopuedeVolveraJugar() {
		Usuario actual = primerUsuario;
		while (actual != null) {
			if (actual.getVidas() == 0) {
				try {
					eliminarUsuario(actual.getId());
				} catch (NoExisteException e) {
					e.printStackTrace();
				}
				return true;
			}
		}
		return false;
	}

	public int darnumeronivel() {
		return niveldentra;
	}

	public boolean eliminarUsuario(String id) throws NoExisteException {

		Usuario actual = null;
		boolean encontro = false;

		if (primerUsuario != null) {
			actual = primerUsuario;
			if (buscarUsuarioPorId(id) == actual) {
				primerUsuario = actual.getSiguiente();

			} else {
				return eliminarUsuarioRecursivo(id, primerUsuario.getSiguiente());
			}

		}
		return encontro;

	}

	private boolean eliminarUsuarioRecursivo(String id, Usuario actual) throws NoExisteException {

		boolean encontrado = false;

		if (actual == null) {
			throw new NoExisteException("No existe");
		} else {
			if (actual == buscarUsuarioPorId(id) && !encontrado) {

				encontrado = true;
				actual.getAnterior().setSiguiente(actual.getSiguiente());
				actual.getSiguiente().setAnterior(actual.getAnterior());

				return encontrado;

			} else {

				return eliminarUsuarioRecursivo(id, actual.getSiguiente());
			}

		}

	}

	public Usuario buscarUsuarioPorId(String id) throws NoExisteException {

		Usuario buscado = null;

		if (primerUsuario == null) {
			throw new NoExisteException("No existe");
		} else if (primerUsuario.getId().equals(id)) {
			buscado = primerUsuario;
		} else {
			buscado = buscarUsuarioRecursivo(id, primerUsuario);
		}

		return buscado;

	}

	private Usuario buscarUsuarioRecursivo(String id, Usuario actual) throws NoExisteException {
		Usuario buscado = null;
		boolean encontro = false;

		if (actual == null) {
			throw new NoExisteException("No existe el due�o con cedula :");
		} else {
			if (actual.getId().equals(id) && !encontro) {
				buscado = actual;
				encontro = true;
				return buscado;
			} else {
				return buscarUsuarioRecursivo(id, actual.getSiguiente());
			}
		}

	}

	public boolean VerificarExistencia(String nombre) {
		boolean encontro = false;
		Usuario actual = primerUsuario;
		while (actual != null && !encontro) {
			if (actual.getNombre().equals(nombre)) {
				encontro = true;
			}
		}
		return encontro;
	}

	// --------------------------------------------------revisar------------------------------
	// public int cantidadVidaRestantes(String nombre) {
	// Iterator<Usuario> primero = usuarios().iterator();
	// Usuario primera;
	// if (usuarios() != null) {
	// while (primero.hasNext()) {
	// primera = (Usuario) primero.next();
	// if (primera.getNombre().equalsIgnoreCase(nombre)) {
	// return primera.cantidadVidaRestantes();
	// }
	//
	// }
	// }
	// return 0;
	// }

	public boolean nopuedeHaberDosusuariosConMismoNombres() {

		Iterator<Usuario> primero = usuarios().iterator();
		Usuario primera;
		Usuario segunda;
		if (usuarios() != null) {
			while (primero.hasNext()) {
				Iterator<Usuario> segundo = usuarios().iterator();
				primera = (Usuario) primero.next();
				while (segundo.hasNext()) {
					segunda = (Usuario) segundo.next();
					if (primera.getNombre().equalsIgnoreCase(segunda.getNombre())) {
						return true;
					}

				}

			}

		}

		return false;

	}

	public boolean nopuedeHaberUsuarioConMenosCeroVidas() {
		boolean encontro = false;
		Usuario actual = primerUsuario;
		while (actual != null && !encontro) {
			if (actual.getVidas() < 0) {
				encontro = true;
			}

		}
		return encontro;
	}

	public boolean nopuedeHaberUsuarioConMas3Vidas() {

		Iterator<Usuario> primero = usuarios().iterator();
		Usuario primera;
		if (usuarios() != null) {
			while (primero.hasNext()) {
				primera = (Usuario) primero.next();
				if (primera.getVidas() > 3) {
					return true;
				}

			}

		}

		return false;

	}

	public Nivel getNiveles() {
		return niveles;
	}

	public void salvarJuego() throws PersistenciaException {
		File archivo = new File("./docs/usuarios()");
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo));
			oos.writeObject(usuarios());
			oos.close();
		} catch (IOException e) {
			throw new PersistenciaException("el error" + e.getMessage());
		}

	}

}
