package Hilos;

import javax.swing.JLabel;
import javax.swing.JPanel;

import interfaz.InterfazConLosHilos;

public class HiloTiempo extends Thread {
	private int contador=30;
	private JLabel lblsegundos;
	private JPanel panel;
	private int cantidadmuertos;
	private boolean acaboeltiempo=false;
	private InterfazConLosHilos principal;
	
	public HiloTiempo(JPanel pa, JLabel lblsegund,int cantidadmuertos1,InterfazConLosHilos ventana) {
		panel = pa;
		lblsegundos = lblsegund;
		cantidadmuertos=cantidadmuertos1;
		principal=ventana;
		contador=30;
	}

	public void run() {
		while (contador>=0 && cantidadmuertos!=5) {
			try {
				lblsegundos.setText(" " + contador--);
				Thread.sleep(1000);

			} catch (InterruptedException e) {

				e.printStackTrace();

			}

		}
	}
	
	public int getContador() {
		return contador;
		
		
	}
	public void setContador(int contador) {
		this.contador = contador;
	}
	
	public void setcantidadmuertos(int cantidad)
	{
		cantidadmuertos=cantidad;
	}
	
	public boolean acaboeltiempo()
	{
		return acaboeltiempo;
	}
	
	public void setAcaboeltiempo(boolean acaboeltiempo) {
		this.acaboeltiempo = acaboeltiempo;
	}
	
	
	
	
	
}
