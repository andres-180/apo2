package Hilos;

import interfaz.InterfazConLosHilos;
import mundo.BebeZombie;
import mundo.PapaZombie;
import mundo.Zombie;

public class HilosPapaZombie extends Thread {
	private int x;
	private int y;
	private String ruta;
	private Zombie zombie;
	private HiloPuntaje puntaje;
	private InterfazConLosHilos panelcito;
	private HiloTiempo tiempo;
	
	public HilosPapaZombie(InterfazConLosHilos g,Zombie b,HiloPuntaje hilitos, HiloTiempo tiempito)
	{
		panelcito=g;
		zombie=b;
		puntaje=hilitos;
		tiempo=tiempito;
		
		
	
	}

	public void move() {
		while (!puntaje.completoMuertes() && tiempo.getContador()!=-1) {
			((PapaZombie)zombie).mover();
			try {
				Thread.sleep(((PapaZombie)zombie).dormir());
				panelcito.refrescar();
			} catch (InterruptedException e) {

			}
		}

	}
		
		
		
	
	public void run()
	{
		move();
	
	}
	
	
	
	
	
	
	
	
}
