package Hilos;

import interfaz.InterfazConLosHilos;
import mundo.AsesinoZombie;
import mundo.BebeZombie;
import mundo.Zombie;

public class HilosAsesinoZombie extends Thread{

	private int x;
	private int y;
	private String ruta;
	private Zombie zombie;
	private HiloPuntaje puntaje;
	private InterfazConLosHilos panelcito;
	private HiloTiempo tiempo;
	
	public HilosAsesinoZombie(InterfazConLosHilos g,Zombie b,HiloPuntaje hilitos, HiloTiempo tiempito)
	{
		panelcito=g;
		zombie=b;
		puntaje=hilitos;
		tiempo=tiempito;
		
		
	
	}

	public void move() {
		while (!puntaje.completoMuertes() && tiempo.getContador()!=-1) {
			((AsesinoZombie)zombie).mover();
			try {
				Thread.sleep(((AsesinoZombie)zombie).dormir());
				panelcito.refrescar();
			} catch (InterruptedException e) {

			}
		}

	}
		
		
		
	
	public void run()
	{
		move();
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
