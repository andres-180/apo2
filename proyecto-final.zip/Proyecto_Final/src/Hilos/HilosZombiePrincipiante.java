package Hilos;

import interfaz.InterfazConLosHilos;
import mundo.BebeZombie;
import mundo.ZombiePrincipiante;
import mundo.Zombie;

public class HilosZombiePrincipiante extends Thread{
	private int x;
	private int y;
	private String ruta;
	private Zombie zombie;
	private HiloPuntaje puntaje;
	private InterfazConLosHilos panelcito;
	private HiloTiempo tiempo;
	
	public HilosZombiePrincipiante(InterfazConLosHilos g,Zombie b,HiloPuntaje hilitos, HiloTiempo tiempito)
	{
		panelcito=g;
		zombie=b;
		puntaje=hilitos;
		tiempo=tiempito;
		
		
	
	}

	public void move() {
		while (!puntaje.completoMuertes() && tiempo.getContador()!=-1) {
				((ZombiePrincipiante) zombie).mover();
				try {
					Thread.sleep(((ZombiePrincipiante)zombie).dormir());
					panelcito.repaint();
				} catch (InterruptedException e) {

				}
			
	}
		}
	
		
	
	public void run()
	{
		move();
	
	}
	
	
}
