package Hilos;

import javax.swing.JLabel;
import javax.swing.JPanel;

import interfaz.InterfazConLosHilos;

public class HiloPuntaje  extends Thread{
	private int puntosGanados;
	private JLabel lblPuntaje;
	private JPanel panelZombie;
	private InterfazConLosHilos principal;
	private int total;
	private int indice;
	private boolean completoMuertes=false;
	
	public HiloPuntaje(JPanel pt, JLabel lblPuntaje, int puntosGanados, int indice,InterfazConLosHilos ventana ){
		panelZombie = pt;
		this.lblPuntaje = lblPuntaje;
		this.puntosGanados = puntosGanados;
		this.indice = indice;
		principal=ventana;
	}
	
	public void run(){
		
		while(indice>=0 && !completoMuertes ){
			total = puntosGanados;
			try {
				lblPuntaje.setText(""+total);
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public int getContador() {
		return puntosGanados;
	}

	public void setContador(int acumulado) {
		puntosGanados+= acumulado;
	}
	
	public boolean completoMuertes()
	{
		return false;
	}
	
	public void setCompletoMuertes(boolean completoMuertes1) {
		this.completoMuertes = completoMuertes1;
	}
	
	
}
