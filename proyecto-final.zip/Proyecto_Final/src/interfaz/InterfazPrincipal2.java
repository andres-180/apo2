package interfaz;

import java.awt.BorderLayout;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import mundo.Juego;
import mundo.NoExisteException;

import mundo.Usuario;
import mundo.YaExisteUsuarioException;

public class InterfazPrincipal2 extends JFrame {

	// Relacion con los demas paneles
	private PanelArbol panelArbol;
	private PanelBanner panelBanner;
	private PanelBusquedasOrdenamientos panelBusquedasOrdenamientos;
	private PanelRegistro panelRegistro;
	private PanelVisualizacion panelVisualizacion;
	private PanelBotones panelBotones;
	private PanelUsuariosRegistrados panelUsuariosRegistrados;
	static int niveles;
	private Juego mundo;

	// Relacion con la Interfaz que aparece antes de comenzar el juego
	private InterfazPreComienzoJuego interfazPreComienzoJuego;

	public InterfazPrincipal2(Juego mundo2) {

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);

		this.setTitle("Proyecto_Final APO II");
		this.setSize(new Dimension(700, 700));
		centrar();
		mundo = mundo2;
		panelArbol=new PanelArbol(mundo);
		panelBanner = new PanelBanner();
		panelBotones = new PanelBotones(this, interfazPreComienzoJuego);

		setLayout(new BorderLayout());
		// this.setLayout(null);
		add(panelBanner, BorderLayout.NORTH);
		add(panelBotones, BorderLayout.SOUTH);

		JPanel panelCentral = new JPanel();
		add(panelCentral, BorderLayout.CENTER);

		panelCentral.setLayout(new GridBagLayout());

		panelRegistro = new PanelRegistro(this);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.fill = GridBagConstraints.BOTH;
		// gbc.ipady = 168;
		gbc.ipadx = 300;
		panelCentral.add(panelRegistro, gbc);

		panelBusquedasOrdenamientos = new PanelBusquedasOrdenamientos(this,mundo);
		gbc = new GridBagConstraints();
		// gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.ipadx = 320;
		gbc.ipady = 250;
		panelCentral.add(panelBusquedasOrdenamientos, gbc);

		panelVisualizacion = new PanelVisualizacion();
		gbc = new GridBagConstraints();
		gbc.gridx = 2;
		gbc.gridy = 1;
		gbc.ipadx = 320;
		gbc.ipady = 220;
		panelCentral.add(panelVisualizacion, gbc);

		panelUsuariosRegistrados = new PanelUsuariosRegistrados(this);
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.ipady = 175;
		gbc.ipadx = 260;
		panelCentral.add(panelUsuariosRegistrados, gbc);

	}

	private void centrar() {
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int xEsquina = (screen.width - getWidth()) / 2;
		int yEsquina = (screen.height - getHeight()) / 2;
		setLocation(xEsquina, yEsquina);
	}
	 public void ordenarBurbuja(){
	    	mundo.ordenamientoBurbujaPorPuntaje();
	    	panelVisualizacion.limpiarDatosUsuario();
	    	panelUsuariosRegistrados.actualizarListaParaOrdenarBurbuja();
	    }

	 public void ordenarInsercion(){
		 mundo.ordenamientoInsercionPorNombre();
	    	panelVisualizacion.limpiarDatosUsuario();
	    	panelUsuariosRegistrados.actualizarListaParaOrdenarInsercion();
	    }
	 
	 public void agregarArbol() throws NoExisteException{
		 mundo.agregarPuntajesAlArbol();
	 }
	 
	 public int buscarPuntaje(String id){
		 
		 return mundo.busquedaBinariaPorPuntaje(id);
	 }
	 
	 public Usuario buscarUsuarioPorId(String id) throws NoExisteException{
		 return mundo.buscarUsuarioPorId(id);
	 }
	 
	 public void dispose() {
			try {
				mundo.salvarJuego();
				super.dispose();

			} catch (Exception e) {
				System.out.println("error de dispose");

			}

		}
	public static void main(String[] args) {
		Juego mundo = null;
		mundo = new Juego(niveles, 200, 300);
		InterfazPrincipal2 id = new InterfazPrincipal2(mundo);
		id.setVisible(true);
		
	}

    
	public PanelBanner getPanelBanner() {
		return panelBanner;
	}

	public void setPanelBanner(PanelBanner panelBanner) {
		this.panelBanner = panelBanner;
	}

	public PanelBusquedasOrdenamientos getPanelBusquedasOrdenamientos() {
		return panelBusquedasOrdenamientos;
	}

	public void setPanelBusquedasOrdenamientos(PanelBusquedasOrdenamientos panelBusquedasOrdenamientos) {
		this.panelBusquedasOrdenamientos = panelBusquedasOrdenamientos;
	}

	public PanelRegistro getPanelRegistro() {
		return panelRegistro;
	}

	public void setPanelRegistro(PanelRegistro panelRegistro) {
		this.panelRegistro = panelRegistro;
	}

	public PanelVisualizacion getPanelVisualizacion() {
		return panelVisualizacion;
	}

	public void setPanelVisualizacion(PanelVisualizacion panelVisualizacion) {
		this.panelVisualizacion = panelVisualizacion;
	}

	public PanelBotones getPanelBotones() {
		return panelBotones;
	}

	public void setPanelBotones(PanelBotones panelBotones) {
		this.panelBotones = panelBotones;
	}

	public PanelUsuariosRegistrados getPanelUsuariosRegistrados() {
		return panelUsuariosRegistrados;
	}

	public void setPanelUsuariosRegistrados(PanelUsuariosRegistrados panelUsuariosRegistrados) {
		this.panelUsuariosRegistrados = panelUsuariosRegistrados;
	}

	public Juego getMundo() {
		return mundo;
	}

	public void setMundo(Juego mundo) {
		this.mundo = mundo;
	}

	public InterfazPreComienzoJuego getInterfazPreComienzoJuego() {
		return interfazPreComienzoJuego;
	}

	public void setInterfazPreComienzoJuego(InterfazPreComienzoJuego interfazPreComienzoJuego) {
		this.interfazPreComienzoJuego = interfazPreComienzoJuego;
	}

	 public void ponerNiveles(int nivel) {
			niveles = nivel;
		}
		public int getNiveles() {
			return niveles;
		}
public boolean agregarUsuarios(String nombre, int edad, String id, String imagen) throws YaExisteUsuarioException{
	
	return mundo.agregarUsuario(nombre, edad, id, imagen);
}
	

}
