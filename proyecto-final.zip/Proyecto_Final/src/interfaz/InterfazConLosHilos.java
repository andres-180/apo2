package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JFrame;

import Hilos.HiloPuntaje;
import Hilos.HiloTiempo;
import Hilos.HilosAsesinoZombie;
import Hilos.HilosBebeZombie;
import Hilos.HilosPapaZombie;
import Hilos.HilosZombiePrincipiante;
import interfaz.DialogoGanador;
import interfaz.DialogoPerdedor;
import interfaz.InterfazConNiveles;
import interfaz.InterfazPreComienzoJuego;
import interfaz.InterfazPrincipal2;
import interfaz.PanelGraphics;
import interfaz.PanelIniciarJuego;
import mundo.Zombie;

public class InterfazConLosHilos extends JFrame {
	private InterfazPrincipal2 principal;
	private PanelGraphics panelgraphics;
	private InterfazConNiveles interNiveles;
	private PanelIniciarJuego panelIniciarJuego;
	
	private ArrayList<HilosBebeZombie> hilosBebe;
	private ArrayList<HilosAsesinoZombie> hilosasesinosEnSerie;
	private ArrayList<HilosZombiePrincipiante> hilosprincipiantes;
	private ArrayList<HilosPapaZombie> hilosPapa;
	
	private int aleatoriox = 0;
	private int aleatorioy = 0;
	private int aleatoriox1 = 10;
	private int aleatorioy1 = 20;
	private int cantidadmuertos = 5;

	private boolean pasaAlSiguienteNivel = false;
	private DialogoPerdedor dialogoperdedor;
	private int cont = 1;

	private HiloTiempo hilotiempo;
	private HiloPuntaje hiloPuntaje;
	private DialogoGanador dialogoganador;

	public InterfazConLosHilos(InterfazPrincipal2 ventana, InterfazConNiveles interfazNivel) {
		interNiveles = interfazNivel;
		cont++;
		principal = ventana;
		setBounds(0, 0, 1280, 700);
		setSize(new Dimension(2000, 700));
		
		panelIniciarJuego = new PanelIniciarJuego(this);

		hilotiempo = new HiloTiempo(panelIniciarJuego, panelIniciarJuego.getLblSegundos(),
				Integer.parseInt(panelIniciarJuego.getLblzombiesEliminados().getText()), this);
		hiloPuntaje = new HiloPuntaje(panelIniciarJuego, panelIniciarJuego.getLblPuntajeAcumulado(),
				Integer.parseInt(panelIniciarJuego.getLblzombiesEliminados().getText()),
				Integer.parseInt(panelIniciarJuego.getLblSegundos().getText()), this);

		setLayout(new BorderLayout());
		panelgraphics = new PanelGraphics(this);

		hilosBebe = new ArrayList<HilosBebeZombie>();
		hilosasesinosEnSerie = new ArrayList<HilosAsesinoZombie>();
		hilosprincipiantes = new ArrayList<HilosZombiePrincipiante>();
		hilosPapa = new ArrayList<HilosPapaZombie>();

		add(panelgraphics, BorderLayout.CENTER);
		add(panelIniciarJuego, BorderLayout.EAST);

	}

	

	public void agregarZombies() {
		aleatoriox = ((int) (Math.random() * (800 - 700)) + 700);
		aleatorioy = ((int) (Math.random() * (500 - 400)) + 400);

		int direccion = 1;
		int velocidad = ((int) (Math.random() * (150 - 100)) + 100);

		int aleatorio = ((int) (Math.random() * (20 - 0)) + 0);

		if (aleatorio <= 4) {
			Zombie zom = principal.getMundo().getNiveles().agregarZombie(90, 62, 2, 2, 20, 0, aleatoriox, aleatorioy,
					"img/bloggif_56427e72aaee2.gif", direccion, velocidad, aleatorio, principal.getNiveles());

			HilosBebeZombie hbz = new HilosBebeZombie(this, zom, hiloPuntaje, hilotiempo);
			hbz.start();

		} else if (aleatorio > 4 && aleatorio <= 9) {

			Zombie zom = principal.getMundo().getNiveles().agregarZombie(71, 90, 2, 2, 20, 0, aleatoriox1, aleatorioy1,
					"img/bloggif_56427e476155d.gif", direccion, velocidad, aleatorio, principal.getNiveles());
			HilosZombiePrincipiante hop = new HilosZombiePrincipiante(this, zom, hiloPuntaje, hilotiempo);
			hop.start();

		}

		else if (aleatorio > 9 && aleatorio <= 14) {

			Zombie zom = principal.getMundo().getNiveles().agregarZombie(50, 90, 2, 2, 20, 0, aleatoriox1, aleatorioy1,
					"img/bloggif_56427dd63cd5b.gif", direccion, velocidad, aleatorio, principal.getNiveles());
			HilosAsesinoZombie hop = new HilosAsesinoZombie(this, zom, hiloPuntaje, hilotiempo);
			hop.start();

		}

		else if (aleatorio > 14 && aleatorio <= 19) {

			Zombie zom = principal.getMundo().getNiveles().agregarZombie(90, 78, 2, 2, 20, 0, aleatoriox1, aleatorioy1,
					"img/bloggif_56427e222d359.gif", direccion, velocidad, aleatorio, principal.getNiveles());
			HilosPapaZombie hop = new HilosPapaZombie(this, zom, hiloPuntaje, hilotiempo);
			hop.start();

		}

	}

	public InterfazPrincipal2 getinterfaz() {
		return principal;
	}


	public PanelIniciarJuego getPanelinfo() {
		return panelIniciarJuego;
	}

	public void incializarHilotiempo() {
		hilotiempo.start();
	}

	public void incializarHiloPuntaje() {
		hiloPuntaje.start();
	}

	public void refrescar() {
		panelgraphics.repaint();

	}

	public HiloTiempo getHilotiempo() {
		return hilotiempo;
	}

	public void setpuntaje(int i) {
		hiloPuntaje.setContador(i);

	}

	public void zombieseliminados(int eliminados) {
		panelIniciarJuego.setLblzombiesEliminados(eliminados);
		hilotiempo.setcantidadmuertos(eliminados);
	}

	public void zombiesMuertesCompletas() {

		hiloPuntaje.setCompletoMuertes(true);
	}

	public void finalizarHilos() {
		if (hilotiempo != null && hilotiempo.isAlive()) {
			hilotiempo.stop();
		}

		if (hiloPuntaje != null && hiloPuntaje.isAlive()) {
			hiloPuntaje.stop();
		}

		principal.getMundo().getNiveles().setZombies();

		panelgraphics.repaint();

		dialogoperdedor = new DialogoPerdedor(this);
		dialogoperdedor.setVisible(true);
		panelIniciarJuego.getNuevojuego().setEnabled(true);
		pasaAlSiguienteNivel = false;

	}

	public int puntaje() {
		return hiloPuntaje.getContador();
	}

	public void empezarNuevoNivel() {

		panelIniciarJuego.setLblzombiesEliminados(0);
		panelIniciarJuego.setLblNivel(cont);

	}

	public void reinciarNivel() {
		interNiveles.setTxtVidas(interNiveles.getTxtVidas() - 1);
		panelIniciarJuego.setLblPuntajeAcumulado(0);
		panelIniciarJuego.setLblSegundos(30);

		hilotiempo = new HiloTiempo(panelIniciarJuego, panelIniciarJuego.getLblSegundos(),
				Integer.parseInt(panelIniciarJuego.getLblzombiesEliminados().getText()), this);
		hiloPuntaje = new HiloPuntaje(panelIniciarJuego, panelIniciarJuego.getLblPuntajeAcumulado(),
				Integer.parseInt(panelIniciarJuego.getLblzombiesEliminados().getText()),
				Integer.parseInt(panelIniciarJuego.getLblSegundos().getText()), this);

		hilosBebe = new ArrayList<HilosBebeZombie>();
		hilosasesinosEnSerie = new ArrayList<HilosAsesinoZombie>();
		hilosprincipiantes = new ArrayList<HilosZombiePrincipiante>();
		hilosPapa = new ArrayList<HilosPapaZombie>();

	}

	public boolean pasaAlSiguienteNivel() {
		return pasaAlSiguienteNivel;
	}

	public void verificar() {
		if (panelgraphics.getEliminados() == cantidadmuertos && hilotiempo.getContador() >= 0) {
			pasaAlSiguienteNivel = true;
			dialogoganador = new DialogoGanador(this);
			dialogoganador.setVisible(true);
		} else if (hilotiempo.getContador() < 0) {
			finalizarHilos();
		}

	}

}
