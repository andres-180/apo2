package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;



public class InterfazConNiveles extends JFrame implements ListSelectionListener {
	private JLabel labNiveles;
	private JLabel labCantVidas;
	private JTextField txtVidas;
	private JScrollPane scroll;
	private JList listaNiveles;
	private JTextPane imagen;
	private int puntaje = 0;
	private InterfazPreComienzoJuego ventana;
	private InterfazConLosHilos interConHilos;
	private ArrayList<String> nivelesLista;
	private InterfazFamiliaMuerta familiamuerta;
	private InterfazPrincipal2 principal;

	public InterfazConNiveles(InterfazPrincipal2 ppal,InterfazPreComienzoJuego v) {
		principal = ppal;
		ventana=v;

		this.setTitle("Comienzo del Juego");
		this.setSize(900, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setResizable(false);
		this.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		labNiveles = new JLabel("Niveles");
		labNiveles.setFont(new Font("Arial Black", Font.BOLD, 20));
		
		labCantVidas = new JLabel("Sus vidas son: ");
		labCantVidas.setFont(new Font("Imprint MT Shadow", Font.ITALIC, 15));
		
		txtVidas = new JTextField("3");
		txtVidas.setEditable(false);
		
		listaNiveles = new JList();
		scroll = new JScrollPane(listaNiveles);
		listaNiveles.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listaNiveles.addListSelectionListener(this);
		listaNiveles.setBorder(new LineBorder(Color.black));
		listaNiveles.setFont(new Font("chiller", Font.ITALIC, 44));
		listaNiveles.setForeground(Color.RED);
		listaNiveles.setBackground(new Color(20, 0, 75));
		
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		imagen = new JTextPane();
		imagen.setBackground(Color.BLACK);
		ImageIcon icono = new ImageIcon("imgs/imagVidas2.jpg");
		imagen.insertIcon(icono);
		imagen.setBorder(new LineBorder(Color.BLACK));
		imagen.setEditable(false);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.fill = GridBagConstraints.NONE;
		add(labNiveles, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 3;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.fill = GridBagConstraints.BOTH;
		add(scroll, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.fill = GridBagConstraints.BOTH;
		add(imagen, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.fill = GridBagConstraints.BOTH;
		add(labCantVidas, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.weightx = 0.0;
		gbc.weighty = 0.0;
		gbc.fill = GridBagConstraints.BOTH;
		add(txtVidas, gbc);

		nivelesLista = new ArrayList<String>();
		String principiante = "Principiante";
		String tecnico = "T�cnico";
		String aniquilador = "Aniquilador Profesional";
		String puntaje = "Score";
		nivelesLista.add(principiante);
		nivelesLista.add(tecnico);
		nivelesLista.add(aniquilador);
		nivelesLista.add(puntaje);

		refrescarLista(nivelesLista);

		centrarVentana();

	}

	public void refrescarLista(ArrayList nuevaLista) {
		listaNiveles.setListData(nuevaLista.toArray());

	}

	public void setTxtVidas(int vidas) {
		txtVidas.setText("" + vidas);
	}

	public int getTxtVidas() {
		return Integer.parseInt(txtVidas.getText());
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		boolean valor = e.getValueIsAdjusting();
		if (Integer.parseInt(txtVidas.getText()) == 0) {
			familiamuerta = new InterfazFamiliaMuerta();
			familiamuerta.setVisible(true);
			this.setVisible(false);

		}
		if (valor) {
			if (listaNiveles.getSelectedIndex() == 0 && !listaNiveles.isSelectionEmpty()) {

				principal.ponerNiveles(1);
				if (principal.getMundo().getNiveles().getZombies().size() != 0) {
					interConHilos.finalizarHilos();
					interConHilos.reinciarNivel();
					interConHilos.empezarNuevoNivel();
				}
			

				interConHilos = new InterfazConLosHilos(principal, this);
				interConHilos.setVisible(true);
				// this.setVisible(false);

			}
		} else if (listaNiveles.getSelectedIndex() == 1) {
			if (interConHilos != null && interConHilos.pasaAlSiguienteNivel()) {
				principal.ponerNiveles(2);
				if (principal.getMundo().getNiveles().getZombies().size() != 0) {
					interConHilos.finalizarHilos();
					interConHilos.reinciarNivel();
					interConHilos.empezarNuevoNivel();
				}
				
				interConHilos = new InterfazConLosHilos(principal, this);
				interConHilos.setVisible(true);
			}
			
			else {
				JOptionPane.showMessageDialog(this, "Usted debe pasar los anteriores niveles","Error",JOptionPane.ERROR_MESSAGE);
			}

		} else if (listaNiveles.getSelectedIndex() == 2 && !listaNiveles.isSelectionEmpty()
				&& interConHilos.pasaAlSiguienteNivel()) {
			if (interConHilos != null && interConHilos.pasaAlSiguienteNivel()) {
				principal.ponerNiveles(3);
				if (principal.getMundo().getNiveles().getZombies().size() != 0) {
					interConHilos.finalizarHilos();
					interConHilos.reinciarNivel();
					interConHilos.empezarNuevoNivel();
				}

				interConHilos = new InterfazConLosHilos(principal, this);
				interConHilos.setVisible(true);
			}
			
			else {
				JOptionPane.showMessageDialog(this, "Usted debe pasar los anteriores niveles","Error",JOptionPane.ERROR_MESSAGE);
			}
		}

		else if (listaNiveles.getSelectedIndex() == 3 && !listaNiveles.isSelectionEmpty()
				&& interConHilos.pasaAlSiguienteNivel()) {
			if (interConHilos != null && interConHilos.pasaAlSiguienteNivel()) {
					principal.ponerNiveles(3);
					if (principal.getMundo().getNiveles().getZombies().size() != 0) {
						interConHilos.finalizarHilos();
						interConHilos.reinciarNivel();
						interConHilos.empezarNuevoNivel();
					}

					interConHilos = new InterfazConLosHilos(principal, this);
					interConHilos.setVisible(true);
				}
				
			else {
				JOptionPane.showMessageDialog(this, "Usted debe pasar los anteriores niveles","Error",JOptionPane.ERROR_MESSAGE);
			}
		}
			

		}

	

	public void obtenerpuntos() {
		if (interConHilos.pasaAlSiguienteNivel() == true && Integer.parseInt(txtVidas.getText()) == 5) {
			puntaje += interConHilos.puntaje();
		} else {
			puntaje += interConHilos.puntaje() - 50;
		}

	}

	private void centrarVentana() {
		Dimension dPantalla = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension dVentana = getSize();

		int xEsquina = (dPantalla.width / 2) - (dVentana.width / 2);
		int yEsquina = (dPantalla.height / 2) - (dVentana.height / 2);

		setLocation(xEsquina, yEsquina);
	}
}
