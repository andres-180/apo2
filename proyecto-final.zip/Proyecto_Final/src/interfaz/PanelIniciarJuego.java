package interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelIniciarJuego extends JPanel implements ActionListener{
public final static String INICIAR_JUEGO = "Iniciar juego";
	
	private InterfazConLosHilos ventana;
	private JButton jugar;
	private JButton nuevojuego;
	private JLabel lblSegundos;
	private JLabel lblPuntajeAcumulado;
	private JLabel lblzombiesEliminados;
	private JLabel lblNivel;
	public final static String JUGAR="jugar";
	public final static String NuevoJUGAR="NUEVOjugar";

	
	public PanelIniciarJuego(InterfazConLosHilos p) {
		
		ventana=p;
	    setLayout(new GridLayout(10, 1));
	    setSize(new Dimension(500,700));
		
	
		
		
		jugar = new JButton("Jugar");
		jugar.setActionCommand(JUGAR);
		jugar.setFont(new Font("Tahoma", Font.PLAIN, 0));
		jugar.setIcon(new ImageIcon("img/btnIniciarJuego.png"));
		jugar.addActionListener(this);
		jugar.setBorder(null);
		jugar.setBackground(Color.black);
		add(jugar);
		
		nuevojuego = new JButton("nuevohjuego");
		nuevojuego.setActionCommand(NuevoJUGAR);
		nuevojuego.setFont(new Font("Tahoma", Font.PLAIN, 0));
		nuevojuego.setIcon(new ImageIcon("img/btnNuevoJuego.png"));
		nuevojuego.addActionListener(this);
		nuevojuego.setEnabled(false);
		nuevojuego.setBorder(null);
		nuevojuego.setBackground(Color.black);
		add(nuevojuego);
		
		
		JLabel lblPuntaje = new JLabel();
		lblPuntaje.setIcon(new ImageIcon("img/lblPuntajeAcumulado.png"));
		lblPuntaje.setBounds(53, 142, 187, 18);
		add(lblPuntaje);
		
		lblPuntajeAcumulado = new JLabel("0");
		lblPuntajeAcumulado.setForeground(Color.WHITE);
		lblPuntajeAcumulado.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPuntajeAcumulado.setBounds(129, 168, 63, 30);
		add(lblPuntajeAcumulado);
		
		JLabel lblTiempoRestante = new JLabel();
		lblTiempoRestante.setIcon(new ImageIcon("img/lblTiempoRestante.png"));
		lblTiempoRestante.setBounds(53, 345, 187, 18);
		add(lblTiempoRestante);
		
		lblSegundos = new JLabel("30");
		lblSegundos.setForeground(Color.WHITE);
		lblSegundos.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblSegundos.setBounds(136, 370, 45, 33);
		add(lblSegundos);
		 
		lblNivel = new JLabel();
			lblNivel.setIcon(new ImageIcon("img/lblNivel.png"));
			lblNivel.setBounds(53, 239, 187, 18);
			add(lblNivel);
	
		lblNivel = new JLabel("1");
		lblNivel.setForeground(Color.WHITE);
		lblNivel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNivel.setBounds(136, 268, 45, 33);
		add(lblNivel);
		
		lblzombiesEliminados = new JLabel();
		lblzombiesEliminados.setIcon(new ImageIcon("img/lblBichosEliminados0.png"));
		lblzombiesEliminados.setBounds(53, 441, 187, 18);
		add(lblzombiesEliminados);
		
		lblzombiesEliminados = new JLabel("0");
		lblzombiesEliminados.setForeground(Color.WHITE);
		lblzombiesEliminados.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblzombiesEliminados.setBounds(136, 477, 45, 30);
		add(lblzombiesEliminados);
		
		
	}

	public void paintComponent(Graphics g) {

		Toolkit ambiente = Toolkit.getDefaultToolkit();
		Image imagen = ambiente.getImage("img/fondo_lateral.png");
		g.drawImage(imagen, 0, 0, this);
	}
	
	public JLabel getLblSegundos() {
		return lblSegundos;
	}
	public JLabel getLblPuntajeAcumulado() {
		return lblPuntajeAcumulado;
	}
	
	public JButton getNuevojuego() {
		return nuevojuego;
	}
	public void setLblPuntajeAcumulado(int puntaje) {
		lblPuntajeAcumulado.setText(""+puntaje);
	}
	
	public JLabel getLblzombiesEliminados() {
		return lblzombiesEliminados;
	}
	public JLabel getLblNivel() {
		return lblNivel;
	}

	public void setLblzombiesEliminados(int zombiesliminadors) {
		lblzombiesEliminados.setText(""+zombiesliminadors);;
	}
	

	public void setLblSegundos(int segundos) {
		lblSegundos.setText(""+segundos);
	}
	public void setLblNivel(int nivel) {
		lblNivel.setText(""+nivel);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		if(e.getActionCommand().equals(JUGAR))
		{
			for(int i=0; i<5;i++)
			{ventana.agregarZombies();}
			ventana.incializarHilotiempo();
			ventana.incializarHiloPuntaje();}
		
		else if(e.getActionCommand().equals(NuevoJUGAR) && nuevojuego.isEnabled())
		{    
		      jugar.setEnabled(false);
			setLblzombiesEliminados(0);
			setLblSegundos(30);
			setLblPuntajeAcumulado(0);
			ventana.reinciarNivel();
			ventana.empezarNuevoNivel();
			
			for(int i=0; i<5;i++)
			{ventana.agregarZombies();}
			
			
			ventana.incializarHilotiempo();
			ventana.incializarHiloPuntaje();
		}
			
		}
		
		
	}
	
	
	
	
	

