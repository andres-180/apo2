package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class InterfazPreComienzoJuego extends JFrame implements ActionListener{
	
//	Constantes
	/**
	 * Boton para Iniciar una nueva partida en el juego
	 */
	private final static String BOTON_SI= "";

	/**
	 * Boton para Cargar una partida del juego que ha sido guardada
	 */
	private final static String BOTON_COMO_AYUDAR = "Cargar Partida";
private String s;
//	Atributos

	private JTextArea txtArea;
	private JButton butSI;
	private JButton butComoAyudar;
	
//	Relacion con la interfaz del juego
	
	private  InterfazConNiveles interNiveles;         
//	Relacion con la InterfazPrincipal
	private InterfazPrincipal2 principal;
	
	public InterfazPreComienzoJuego(InterfazPrincipal2 ppal){
		
		principal=ppal;
		setResizable(true);
		setSize(600,400);
		centrar();
		setLayout(new BorderLayout());
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
		JPanel nuevoPanel2= new JPanel();
		add(nuevoPanel2, BorderLayout.CENTER);
	
		
		txtArea= new JTextArea();
		txtArea.setBackground(Color.DARK_GRAY);
		
		txtArea.setFont(new Font("Chiller", Font.ROMAN_BASELINE, 28));
		txtArea.setText("           En menos de una semana se ha propagado una "+"\n"
						+"          peligrosa enfermedad en casi todo el mundo,"+"\n"
						+"          la cual provoca que las personas muertas vuelvan "+"\n"
						+"          a la vida a querer saciar su sed de sandre."+"\n"
						+"           Mientras los doctores encuentran una cura "
						+"\n"+"          debemos unir fuerzas para aniquilar esta plaga."+
						"\n"+"\n"+"	          �Y t� nos ayudar�s?");
		txtArea.setForeground(Color.WHITE);
		
		txtArea.setEditable(false);
		

		add(txtArea);
		
		JPanel nuevoPanel= new JPanel();
		add(nuevoPanel, BorderLayout.SOUTH);
		
		butSI=new JButton("S�");
		butSI.setBackground(Color.WHITE);
		butSI.setForeground(Color.BLACK);
		butSI.setActionCommand(BOTON_SI);
		butSI.addActionListener(this);
		butSI.setBounds(0, 180, 220, 20);
		
	
		nuevoPanel.add(butSI);
		
		
		butComoAyudar=new JButton("�C�mo puedo ayudar?");
		butComoAyudar.setBackground(Color.WHITE);
		butComoAyudar.setForeground(Color.BLACK);
		butComoAyudar.setActionCommand(BOTON_COMO_AYUDAR);
		butComoAyudar.addActionListener(this);
		butComoAyudar.setBounds(0, 180, 220, 20);
		nuevoPanel.add(butComoAyudar);

//		setUndecorated(true);
	}
	

	 private void centrar( )
	    {
	        Dimension screen = Toolkit.getDefaultToolkit( ).getScreenSize( );
	        int xEsquina = ( screen.width - getWidth( ) ) / 2;
	        int yEsquina = ( screen.height - getHeight( ) ) / 2;
	        setLocation( xEsquina, yEsquina );
	    }
	
	@Override
	public void actionPerformed(ActionEvent e) {
String comando=e.getActionCommand();
		
		if(comando.equals(BOTON_SI)){
			interNiveles=new InterfazConNiveles(principal,this);
			interNiveles.setVisible(true);
			this.setVisible(false);
			
			
		}
		else if(comando.equals(BOTON_COMO_AYUDAR)){
			JOptionPane.showMessageDialog(this, "Es facil solo debes dar dos golpes a cada zombie");
		}
	
	}
}
