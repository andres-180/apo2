package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelBotones extends JPanel implements ActionListener{
	
	//Constantes
	/**
	 * Boton para Iniciar una nueva partida en el juego
	 */
	private final static String BOTON_JUEGO_NUEVO= "Juego Nuevo";


	//Atributos
	
	private JButton butJuegoNuevo;
	
	
//	Relacion con InterfazPrincipal
	private InterfazPrincipal2 principal;
	
//	Relacion con la InterfazPreComienzoJuego
	private InterfazPreComienzoJuego interfazPreJuego;
	
	
	public PanelBotones(InterfazPrincipal2 ppal,InterfazPreComienzoJuego preJuego){
		
		principal=ppal;
		interfazPreJuego=preJuego;
		
		setLayout(new GridLayout(1,2));
		setBorder(new TitledBorder("Opciones"));
		butJuegoNuevo=new JButton("Juego Nuevo");
		butJuegoNuevo.setActionCommand(BOTON_JUEGO_NUEVO);
		butJuegoNuevo.addActionListener(this);
	        

			
		add(butJuegoNuevo);

	

	
		
	}


	@Override
	public void actionPerformed(ActionEvent a) {
		String comando=a.getActionCommand();
		
		if(comando.equals(BOTON_JUEGO_NUEVO)){
			interfazPreJuego=new InterfazPreComienzoJuego(principal);
			interfazPreJuego.setVisible(true);
//			principal.setVisible(false);
			
			
		}

		
	}

}
