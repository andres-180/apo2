package interfaz;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelFamiliaMuerta extends JPanel{
	
	private InterfazFamiliaMuerta principal;
	private JLabel fondoFamilia;

	public PanelFamiliaMuerta(InterfazFamiliaMuerta fm) {
		// TODO Auto-generated constructor stub
		
		principal=fm;
		this.setSize(655,400);
		fondoFamilia= new JLabel(new ImageIcon("img/FAMILIAZOMBIEMODERNAFINAL.jpeg"));
		add(fondoFamilia);
	}

}
