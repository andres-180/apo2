package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import mundo.NoExisteException;
import mundo.YaExisteUsuarioException;

public class PanelRegistro extends JPanel implements ActionListener{

	// Constante
	/**
	 * Boton que representa el registro del usuario
	 */
	private final static String BOTON_REGISTRARSE = "Registrarse";
	
	/**
	 * Boton que representa el registro del usuario
	 */
	private final static String BOTON_CARGAR_IMG = "Cargar imagen";

	// Atributos
	private JLabel labNombre;
	private JLabel labEdad;
	private JLabel labID;
	private JLabel labImagen;
	
	private String txtImagen;
	private JTextField txtNombre;
	private JTextField txtEdad;
	private JTextField txtID;

	private JButton butCargarImg;
	private JButton butRegistrarse;

	// Relacion con la InterfazPrincipal
	private InterfazPrincipal2 principal;

	public PanelRegistro(InterfazPrincipal2 ppal) {

		principal = ppal;

		this.setLayout(null);
		setBorder(new TitledBorder("Registrate aqu�"));

		labNombre = new JLabel("Nombre: ");
		labNombre.setBounds(10, 120, 90, 20);

		labEdad = new JLabel("Edad: ");
		labEdad.setBounds(10, 145, 90, 20);

		labID = new JLabel("Id: ");
		labID.setBounds(10, 170, 90, 20);
		
		ImageIcon icono = new ImageIcon("img/Avatares/minionSacaLengua.png");
		labImagen=new JLabel();
		labImagen.setIcon(icono);
		labImagen.setBounds(65, 20, 90, 90);
		labImagen.setBorder(new TitledBorder(""));
		txtImagen="Avatares/minionSacaLengua.png";
		

		txtNombre = new JTextField("");
		txtNombre.setBounds(70, 120, 170, 20);
		txtNombre.setEditable(true);

		txtEdad = new JTextField("");
		txtEdad.setBounds(70,  145, 170, 20);
		txtEdad.setEditable(true);

		txtID = new JTextField("");
		txtID.setBounds(70, 170, 170, 20);
		txtID.setEditable(true);
		
		butCargarImg = new JButton("Carga tu imagen");
		butCargarImg.setActionCommand(BOTON_CARGAR_IMG);
		butCargarImg.addActionListener(this);
		butCargarImg.setBounds(165, 60, 130, 25);

		butRegistrarse = new JButton("Registrate");
		butRegistrarse.setActionCommand(BOTON_REGISTRARSE);
		butRegistrarse.addActionListener(this);
		butRegistrarse.setBounds(68, 204, 170, 25);

		add(butCargarImg);
		add(labNombre);
		add(labEdad);
		add(labID);
		add(labImagen);
		add(txtNombre);
		add(txtEdad);
		add(txtID);
		add(butRegistrarse);

	}
	private String preguntarNombreArchivoAbrir() {
	
		JFileChooser fc = new JFileChooser("./Avatares");
		fc.setDialogTitle("Abrir Archivo de Egresados");

		File archivoEgresados = null;
		int resultado = fc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			archivoEgresados = fc.getSelectedFile();
		}

		String nombreArchivo = null;
		if (archivoEgresados != null) {
			nombreArchivo = archivoEgresados.getAbsolutePath();

		}

		return nombreArchivo;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		
		if(comando.equals(BOTON_CARGAR_IMG)){
			txtImagen = preguntarNombreArchivoAbrir();
			ImageIcon icono = new ImageIcon(txtImagen);
			labImagen.setIcon(icono);
		}
		else if(comando.equals(BOTON_REGISTRARSE)){
			boolean atrapado=false;
			try{
				atrapado=principal.agregarUsuarios(txtNombre.getText(), Integer.parseInt(txtEdad.getText()), txtID.getText(), txtImagen);
			
				
			}catch(YaExisteUsuarioException e1){
				JOptionPane.showMessageDialog(this, "Ya existe este usuario, por favor digite un nuevo Id", "Error", JOptionPane.ERROR_MESSAGE);
			}
			if(atrapado==true){
				JOptionPane.showMessageDialog(this, "Se agrego un usuario", "Informaci�n", JOptionPane.INFORMATION_MESSAGE);
				principal.getPanelUsuariosRegistrados().llenarLista();
				txtNombre.setText("");

				txtEdad.setText("");
				txtID.setText("");
				txtNombre.setText("");
				
			}
		}
	}

}
