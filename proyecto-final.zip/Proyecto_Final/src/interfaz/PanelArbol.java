package interfaz;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;
import java.awt.Color;
import mundo.Juego;
import mundo.PuntajeGanador;

public class PanelArbol extends JPanel{
private Juego puntaje;
	
	public PanelArbol(Juego p){
		puntaje = p;
		setPreferredSize(new Dimension(500, 300));
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent((java.awt.Graphics) g);
		PuntajeGanador raiz = puntaje.getGanadorRaiz();
		int x = (getWidth()/2)-110/2;
		int y = 10 ;
		pintar(g,x,y, raiz);
	
	}
	
	public void pintar(Graphics g, int x, int y,PuntajeGanador cont){
		if(cont!= null){
			((java.awt.Graphics) g).setColor(Color.BLUE);
			g.fillOval(x, y, 110, 40);
			((java.awt.Graphics) g).setColor(Color.GRAY);
			g.drawOval(x, y, 110, 40);
			( (java.awt.Graphics) g).setFont(new Font("Arial", Font.BOLD, 12));
			g.drawString(cont.getPuntaje() +"", x+110/3,y + 40/2);
			
			if(cont.getIzq()!= null){
				pintar(g,x - 110,y+ 2*40,cont.getIzq());
				g.drawLine(x+110/2, y+40, x-110/2, y+ 2*40);
			}
			if(cont.getDer()!= null){
				pintar(g, x + 100, y + 2*40, cont.getDer());
				g.drawLine(x+110/2, y+40, x+ 2 *110 - (110 / 2), y+ 2*40);
			}
		
			
		}
	} 



}
