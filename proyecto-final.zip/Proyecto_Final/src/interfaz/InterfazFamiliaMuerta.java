package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;import javax.swing.border.Border;

public class InterfazFamiliaMuerta extends JFrame {
	
	private JLabel banner;
	private PanelFamiliaMuerta panelFondo;

	public InterfazFamiliaMuerta() {
		// TODO Auto-generated constructor stub
		this.setSize(655,563);
		this.setBackground(Color.black);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);
		this.setLayout(new BorderLayout());
		
		banner=new JLabel(new ImageIcon("img/bannerMuerte.jpg"));
		panelFondo=new PanelFamiliaMuerta(this);
		add(banner, BorderLayout.NORTH);
		add(panelFondo, BorderLayout.CENTER);
		
		centrarVentana();
		
	}
	
	public static void main(String[] args) {
		InterfazFamiliaMuerta n= new InterfazFamiliaMuerta();
		n.setVisible(true);
	}
	
	private void centrarVentana() {
		Dimension dPantalla = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension dVentana = getSize();

		int xEsquina = (dPantalla.width / 2) - (dVentana.width / 2);
		int yEsquina = (dPantalla.height / 2) - (dVentana.height / 2);

		setLocation(xEsquina, yEsquina);
	}

}
