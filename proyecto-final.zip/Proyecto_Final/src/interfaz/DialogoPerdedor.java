package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



public class DialogoPerdedor extends JDialog implements ActionListener {
	private final JPanel contentPanel = new JPanel();
	private static  InterfazConLosHilos principal;
	public final static String OK="ok";
	

	/**
	 * Launch the application.
	 */
	/**
	 * Create the dialog.
	 */
	public DialogoPerdedor(InterfazConLosHilos obj) {
		principal=obj;
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(199, 21, 133));
		contentPanel.setForeground(new Color(139, 0, 139));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Perdiste, DESEA reiniciar NIVEL                                 ");
			lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 17));
			lblNewLabel.setBounds(23, 11, 388, 206);
			contentPanel.add(lblNewLabel);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("SI");
				okButton.setActionCommand(OK);
				okButton.addActionListener(this);
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("NO");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(this);
				buttonPane.add(cancelButton);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equalsIgnoreCase(OK))
		{this.setVisible(false);
         principal.setVisible(true);
		}
		else
		{
			this.setVisible(false);
			principal.setVisible(false);
			
			
		}
			
		
		
		
	}

}
