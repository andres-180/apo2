package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import mundo.Usuario;



public class PanelUsuariosRegistrados extends JPanel implements ListSelectionListener{
	
	
	
//	Atributos
	
	/**Relacion con la interfaz*/
	private InterfazPrincipal2 principal;
	
	/**
     * Es la lista que se muestra de los usuarios registrados
     */
    private JList listaUsuarios;

    /**
     * Componente de desplazamiento para contener la lista gr�fica
     */
    private JScrollPane scroll;
    
    
    public PanelUsuariosRegistrados(InterfazPrincipal2 ppal){
    	
    	
    	
    	principal=ppal;
  	  setLayout( new BorderLayout( ) );
        setBorder( new CompoundBorder( new EmptyBorder( 4, 3, 3, 3 ),
      		  new TitledBorder( "Usuarios Registrados" ) ) );
        
        listaUsuarios = new JList<Usuario>();
        listaUsuarios.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );
        listaUsuarios.addListSelectionListener( this );

        scroll = new JScrollPane( listaUsuarios );
        scroll.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
        scroll.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        scroll.setBorder( new CompoundBorder( new EmptyBorder( 3, 3, 3, 3 ), 
      		  new LineBorder( Color.BLACK, 1 ) ) );

        add( scroll, BorderLayout.CENTER );
    }
    public void llenarLista(){
    	DefaultListModel model = new DefaultListModel();
    	if(principal.getMundo().usuarios()!= null){
    		for (int i = 0; i < principal.getMundo().usuarios().size(); i++) {
    			Usuario p = principal.getMundo().usuarios().get(i);
    			model.addElement(p.getNombre()+" , su Id: "+p.getId());
			}
    		
    	}
    	listaUsuarios.setModel(model);
    	
//    	
    }
    
    public void actualizarLista(){
    	listaUsuarios.setListData( principal.getMundo().usuarios().toArray());
    
    }
    public void actualizarListaParaOrdenarInsercion(){
    	listaUsuarios.setListData( principal.getMundo().ordenamientoInsercionPorNombre().toArray());
    
    }
    public void actualizarListaParaOrdenarBurbuja(){
    	listaUsuarios.setListData( principal.getMundo().ordenamientoBurbujaPorPuntaje().toArray());
    
    }

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	
    

}
