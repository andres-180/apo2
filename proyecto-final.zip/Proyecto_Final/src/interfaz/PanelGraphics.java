package interfaz;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JPanel;

import mundo.AsesinoZombie;
import mundo.AsesinoZombie;
import mundo.BebeZombie;
import mundo.BebeZombie;
import mundo.PapaZombie;
import mundo.ZombiePrincipiante;
import mundo.Zombie;
import mundo.ZombiePrincipiante;

public class PanelGraphics extends JPanel implements MouseListener {
	private InterfazConLosHilos ventanaHilos;
	private int eliminados = 0;
	private int CANTIDAD = 20;

	public PanelGraphics(InterfazConLosHilos p) {
		ventanaHilos = p;
		setSize(new Dimension(1200, 700));

		addMouseListener(this);
	}

	protected void paintComponent(Graphics grafico) {
		super.paintComponent(grafico);

		Toolkit img1 = Toolkit.getDefaultToolkit();
		Image fondo = img1.getImage("imgs/fondito.jpg");
		grafico.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);

		// El graphics a cada hilo de zombie

		for (int i = 0; i < ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().size(); i++) {
			Zombie zombie = ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().get(i);
			Toolkit img = Toolkit.getDefaultToolkit();

			Image imagen = null;

			if (zombie instanceof BebeZombie) {
				imagen = img.getImage(((BebeZombie) zombie).getRuta());

				grafico.drawImage(imagen, ((BebeZombie) zombie).getposx(), ((BebeZombie) zombie).getposy(), this);
			}
			if (zombie instanceof AsesinoZombie) {
				imagen = img.getImage(((AsesinoZombie) zombie).getRuta());
				grafico.drawImage(imagen, ((AsesinoZombie) zombie).getposx(), ((AsesinoZombie) zombie).getposy(), this);

			}
			if (zombie instanceof ZombiePrincipiante) {
				imagen = img.getImage(((ZombiePrincipiante) zombie).getRuta());
				grafico.drawImage(imagen, ((ZombiePrincipiante) zombie).getposx(),
						((ZombiePrincipiante) zombie).getposy(), this);
			}
			if (zombie instanceof PapaZombie) {
				imagen = img.getImage(((PapaZombie) zombie).getRuta());
				grafico.drawImage(imagen, ((PapaZombie) zombie).getposx(), ((PapaZombie) zombie).getposy(), this);
			}

		}

	}

	public InterfazConLosHilos getPrincipal() {
		return ventanaHilos;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		ventanaHilos.verificar();
		if (e.getButton() == MouseEvent.BUTTON1) {
			int ejexmouse = e.getX();
			int ejeymouse = e.getY();
			for (int i = 0; i < ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().size(); i++) {
				Zombie zombie = ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().get(i);
				if (zombie instanceof BebeZombie) {
					int ejex = ((BebeZombie) zombie).getposx() + ((BebeZombie) zombie).getancho();
					int ejey = ((BebeZombie) zombie).getposy() + ((BebeZombie) zombie).getalto();

					if (ejexmouse > ((BebeZombie) zombie).getposx() && ejexmouse < ejex
							&& ejeymouse > ((BebeZombie) zombie).getposy() && ejeymouse < ejey) {
						ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().remove(i);
						ventanaHilos.setpuntaje(((BebeZombie) zombie).getpuntos());
						eliminados++;
					}

				} else if (zombie instanceof AsesinoZombie) {

					int ejex = ((AsesinoZombie) zombie).getposx() + ((AsesinoZombie) zombie).getancho();
					int ejey = ((AsesinoZombie) zombie).getposy() + ((AsesinoZombie) zombie).getalto();

					if (ejexmouse > ((AsesinoZombie) zombie).getposx() && ejexmouse < ejex
							&& ejeymouse > ((AsesinoZombie) zombie).getposy() && ejeymouse < ejey) {
						ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().remove(i);
						ventanaHilos.setpuntaje(((AsesinoZombie) zombie).getCantidadPuntos());
						eliminados++;
					}

				}

				else if (zombie instanceof ZombiePrincipiante) {
					int ejex = ((ZombiePrincipiante) zombie).getposx() + ((ZombiePrincipiante) zombie).getAncho();
					int ejey = ((ZombiePrincipiante) zombie).getposy() + ((ZombiePrincipiante) zombie).getAlto();

					if (ejexmouse > ((ZombiePrincipiante) zombie).getposx() && ejexmouse < ejex
							&& ejeymouse > ((ZombiePrincipiante) zombie).getposy() && ejeymouse < ejey) {
						ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().remove(i);
						ventanaHilos.setpuntaje(((ZombiePrincipiante) zombie).getCantidadPuntos());
						eliminados++;

					}

				}

				else if (zombie instanceof PapaZombie) {
					int ejex = ((PapaZombie) zombie).getposx() + ((PapaZombie) zombie).getAncho();
					int ejey = ((PapaZombie) zombie).getposy() + ((PapaZombie) zombie).getAlto();

					if (ejexmouse > ((PapaZombie) zombie).getposx() && ejexmouse < ejex
							&& ejeymouse > ((PapaZombie) zombie).getposy() && ejeymouse < ejey) {
						ventanaHilos.getinterfaz().getMundo().getNiveles().getZombies().remove(i);
						ventanaHilos.setpuntaje(((PapaZombie) zombie).getCantidadPuntos());
						eliminados++;
					}

				}

				ventanaHilos.zombieseliminados(eliminados);

				repaint();
			}

		}

	}

	public int getEliminados() {
		return eliminados;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
