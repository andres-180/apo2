package interfaz;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelBanner extends  JPanel {
	private JLabel labImagen;
	//relacion con la interfaz ppal.
	private InterfazPrincipal2 principal;
	
	public PanelBanner (){
		
	
		labImagen= new JLabel(new ImageIcon("./imgs/BannerZombie1.jpg"));
		setBorder(new TitledBorder(""));
		add(labImagen, BorderLayout.NORTH);
		
	}
	
	
	
	
}
