package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import mundo.Juego;
import mundo.NoExisteException;
import mundo.Usuario;

public class PanelBusquedasOrdenamientos extends JPanel implements
		ActionListener {

	// Constantes

	/**
	 * Boton que representa el ordenamiento por nombre con insercion
	 */
	private final static String BOTON_INSERCION = "Ordenar por nombre con inserci�n";

	
	/**
	 * Boton que representa el ordenamiento por puntaje con burbuja
	 */
	private final static String BOTON_BURBUJA = "Ordenar por puntaje con burbuja";

	/** Boton que representa la busqueda del usuario por el  puntaje
	 * 
	 */
	private final static String BOTON_BUSCAR_PUNTAJE = "Buscar usuario por puntaje";

	/**
	 * Boton que representa la busqueda del usuario por ID
	 */
	private final static String BOTON_BUSCAR_PORID = "Buscar usuario por su Id";
	

	/**
	 * Boton que representa la visualizacion  del usuario por Nombre en un arbol binario
	 */
	private final static String MOSTRAR_USUARIOS_PUNTAJE= "Mostrar a los usuarios en un arbol binario por nombre";


	/**
	 * Boton que representa cuando se agrega el punatje de un usuario
	 */
	private final static String AGREGAR_PUNTAJES_ARBOL= "Agregar usuario por puntaje";



	
	private DialogoArbol dialogo;

	// Atributos
	private JButton butAgregarPoPuntaje;
	private JButton butOrdenarNombreInsercion;

	private JButton butOrdenarPuntajeBurbuja;
	private JButton butBuscarPuntaje;
	private JButton butBuscarID;
	private JButton butMostrarPorNombre;

	// relacion con la interfaz principal
	private InterfazPrincipal2 principal;

	public PanelBusquedasOrdenamientos(InterfazPrincipal2 ppal,Juego p) {
		principal = ppal;

		dialogo= new DialogoArbol(p);
		this.setLayout(null);
		setBorder(new TitledBorder("B�squeda y Ordenamiento"));
		
		butMostrarPorNombre = new JButton("Mostrar puntajes de usuarios");
		butMostrarPorNombre.setActionCommand(MOSTRAR_USUARIOS_PUNTAJE);
		butMostrarPorNombre.addActionListener(this);
		butMostrarPorNombre.setBounds(20, 20, 280, 24);
		
		butAgregarPoPuntaje = new JButton("Agregar puntaje al �rbol");
		butAgregarPoPuntaje.setActionCommand(AGREGAR_PUNTAJES_ARBOL);
		butAgregarPoPuntaje.addActionListener(this);
		butAgregarPoPuntaje.setBounds(20, 55, 280, 24);
		
		butBuscarPuntaje = new JButton("Buscar puntaje del usuario");
		butBuscarPuntaje.setActionCommand(BOTON_BUSCAR_PUNTAJE);
		butBuscarPuntaje.addActionListener(this);
		butBuscarPuntaje.setBounds(20, 90, 280, 24);
		
		butBuscarID = new JButton("Buscar usuario por su ID");
		butBuscarID.setActionCommand(BOTON_BUSCAR_PORID);
		butBuscarID.addActionListener(this);
		butBuscarID.setBounds(20, 125, 280, 24);
		
		butOrdenarNombreInsercion = new JButton("Ordenar usuario por nombre con Inserci�n");
		butOrdenarNombreInsercion.setActionCommand(BOTON_INSERCION);
		butOrdenarNombreInsercion.addActionListener(this);
		butOrdenarNombreInsercion.setBounds(20, 160, 280, 24);


		butOrdenarPuntajeBurbuja = new JButton(	"Ordenar usuario por puntaje con Burbuja");
		butOrdenarPuntajeBurbuja.setActionCommand(BOTON_BURBUJA);
		butOrdenarPuntajeBurbuja.addActionListener(this);
		butOrdenarPuntajeBurbuja.setBounds(20, 195, 280, 24);
		
		add(butAgregarPoPuntaje);
		add(butBuscarPuntaje);
		add(butMostrarPorNombre);
		add(butBuscarID);
		add(butOrdenarNombreInsercion);
		add(butOrdenarPuntajeBurbuja);
		

	}

	public void abrirVentana(){
		dialogo.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		if(comando.equals(MOSTRAR_USUARIOS_PUNTAJE)){
			abrirVentana();
		}else if(comando.equals(AGREGAR_PUNTAJES_ARBOL)){
			try {
				principal.agregarArbol();
			} catch (NoExisteException e1) {
			
				e1.getMessage();
			}
		}
		else if(comando.equals(BOTON_BUSCAR_PUNTAJE)){
			String id=JOptionPane.showInputDialog("Ingrese su Id:");
			
			int valor = principal.buscarPuntaje(id);
			JOptionPane.showMessageDialog(this, valor +"");
		}
		else if(comando.equals(BOTON_BUSCAR_PORID)){
			String id=JOptionPane.showInputDialog("Ingrese su Id:");
			try {
				Usuario p = principal.buscarUsuarioPorId(id);
				principal.getPanelVisualizacion().getTxtNombre().setText(p.getNombre());
				principal.getPanelVisualizacion().getTxtEdad().setText(p.getEdad()+ " ");
				principal.getPanelVisualizacion().getTxtID().setText(p.getId());
				principal.getPanelVisualizacion().getTxtPuntaje().setText(p.getPuntaje()+ " ");
				
				
			} catch (NoExisteException e1) {
				
				e1.getMessage();
			}
		}else if(comando.equals(BOTON_INSERCION)){
			principal.ordenarInsercion();
			
		}
		else if(comando.equals(BOTON_BURBUJA)){
			principal.ordenarBurbuja();
		}

	}


}
