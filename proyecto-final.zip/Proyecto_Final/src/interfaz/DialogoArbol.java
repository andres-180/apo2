package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import mundo.Juego;

public class DialogoArbol extends JDialog implements ActionListener  {

private final static String CERRAR ="Cerrar";
	
	private JButton botonCerrar;
	private PanelArbol panelArbol;
	
	public DialogoArbol(Juego p){
		

	JPanel panel = new JPanel(new GridLayout(1,3));
	botonCerrar = new JButton("Cerra");
	botonCerrar.setActionCommand(CERRAR);
	botonCerrar.addActionListener(this);
	
	panel.add(new JLabel("             "));
	panel.add(botonCerrar);
	panel.add(new JLabel("             "));
	panelArbol = new PanelArbol(p);
	add(panelArbol, BorderLayout.CENTER);
	add(panel , BorderLayout.SOUTH);
	
		setSize(500,300);
		centrar();
	}

	public void actionPerformed(ActionEvent arg0) {
		String comando = arg0.getActionCommand();
		if(comando.equals("Cerrar")){
			cerrar();
		}
		
	}

	private void cerrar() {
		dispose();
		
	}
	
	 private void centrar( )
	    {
	        Dimension screen = Toolkit.getDefaultToolkit( ).getScreenSize( );
	        int xEsquina = ( screen.width - getWidth( ) ) / 2;
	        int yEsquina = ( screen.height - getHeight( ) ) / 2;
	        setLocation( xEsquina, yEsquina );
	    }
	
	


}
