package interfaz;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import mundo.Usuario;

public class PanelVisualizacion extends JPanel {
	
//	Atributos
	
	private JLabel labNombre;
	private JLabel labEdad;
	private JLabel labID;
	private JLabel labPuntaje;
	
	private JTextField txtNombre;
	private JTextField txtEdad;
	private JTextField txtID;
	private JTextField txtPuntaje;
	
	//Relacion con el mundo
	
	private Usuario mundo;
	
	
	public PanelVisualizacion(){
		
		
		this.setLayout(null);
		setBorder(new TitledBorder("Datos del Programador"));

		labNombre= new JLabel("Nombre: ");
		labNombre.setBounds(30,40,100,28);
		
		labEdad= new JLabel("Edad: ");
		labEdad.setBounds(30,80,100,28);
		
		labID= new JLabel("Id: ");
		labID.setBounds(30,120,100,28);
		

		labPuntaje= new JLabel("Puntaje: ");
		labPuntaje.setBounds(15,160,100,28);
		
		
		txtNombre= new JTextField();
		txtNombre.setBounds(90, 40, 160, 28);
		txtNombre.setEditable(false);
        
        
		txtEdad= new JTextField("");
		txtEdad.setBounds(90, 80, 160, 28);
		txtEdad.setEditable(false);
        
        
		txtID= new JTextField("");
		txtID.setBounds(90, 120, 160, 28);
		txtID.setEditable(false);
        
        
		txtPuntaje= new JTextField("");
		txtPuntaje.setBounds(90, 160,160, 28);
		txtPuntaje.setEditable(false);
        
		add(labNombre);
		add(labEdad);
		add( labID);
		add(labPuntaje);
		add(txtNombre);
		add(txtEdad);
		add( txtID);
		add(txtPuntaje);
		
		
	}
	
	public void limpiarDatosUsuario( )
    {
       
        txtNombre.setText( "" );
        txtEdad.setText( "" );
        txtID.setText( "" );
        txtPuntaje.setText("");
    }

	public JLabel getLabNombre() {
		return labNombre;
	}

	public void setLabNombre(JLabel labNombre) {
		this.labNombre = labNombre;
	}

	public JLabel getLabEdad() {
		return labEdad;
	}

	public void setLabEdad(JLabel labEdad) {
		this.labEdad = labEdad;
	}

	public JLabel getLabID() {
		return labID;
	}

	public void setLabID(JLabel labID) {
		this.labID = labID;
	}

	public JLabel getLabPuntaje() {
		return labPuntaje;
	}

	public void setLabPuntaje(JLabel labPuntaje) {
		this.labPuntaje = labPuntaje;
	}

	public JTextField getTxtNombre() {
		return txtNombre;
	}

	public void setTxtNombre(JTextField txtNombre) {
		this.txtNombre = txtNombre;
	}

	public JTextField getTxtEdad() {
		return txtEdad;
	}

	public void setTxtEdad(JTextField txtEdad) {
		this.txtEdad = txtEdad;
	}

	public JTextField getTxtID() {
		return txtID;
	}

	public void setTxtID(JTextField txtID) {
		this.txtID = txtID;
	}

	public JTextField getTxtPuntaje() {
		return txtPuntaje;
	}

	public void setTxtPuntaje(JTextField txtPuntaje) {
		this.txtPuntaje = txtPuntaje;
	}

	public Usuario getMundo() {
		return mundo;
	}

	public void setMundo(Usuario mundo) {
		this.mundo = mundo;
	}


}
